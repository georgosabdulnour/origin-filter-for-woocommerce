Origin Filter for WooCommerce 
Contributors: georgos abdulnour
Tags: woo-commerce, filter, orders, origin
Tested up to: 6.6
Stable tag: 1.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Short Description: Adds a filter to WooCommerce orders to filter by order origin and displays total sales for the filtered origin.
